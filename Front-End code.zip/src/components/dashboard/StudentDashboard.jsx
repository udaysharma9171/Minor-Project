import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "../../components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../../components/ui/tabs";
import { Progress } from "../../components/ui/progress";
import { BookOpen, Clock, Award, Video } from 'lucide-react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer
} from 'recharts';

const StudentDashboard = () => {
  // Sample data - In real app, this would come from API
  const assignments = [
    { id: 1, title: "Math Quiz 1", dueDate: "2024-11-30", status: "pending", subject: "Mathematics", score: null },
    { id: 2, title: "Physics Lab Report", dueDate: "2024-11-28", status: "submitted", subject: "Physics", score: 85 },
    { id: 3, title: "Literature Essay", dueDate: "2024-11-25", status: "graded", subject: "English", score: 92 }
  ];

  const performanceData = [
    { month: 'Sep', Mathematics: 78, Physics: 82, English: 88 },
    { month: 'Oct', Mathematics: 82, Physics: 85, English: 90 },
    { month: 'Nov', Mathematics: 88, Physics: 88, English: 92 }
  ];

  const recommendations = [
    {
      id: 1,
      title: "Advanced Algebra Concepts",
      type: "video",
      subject: "Mathematics",
      difficulty: "intermediate",
      duration: "15 mins"
    },
    {
      id: 2,
      title: "Physics Problem Solving",
      type: "practice",
      subject: "Physics",
      difficulty: "advanced",
      duration: "30 mins"
    }
  ];

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      {/* Header Section */}
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Welcome back, Student!</h1>
        <div className="text-sm text-gray-500">
          Last login: {new Date().toLocaleDateString()}
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="flex items-center p-6">
            <Clock className="h-8 w-8 text-blue-500 mr-4" />
            <div>
              <p className="text-sm text-gray-500">Pending Assignments</p>
              <p className="text-2xl font-bold">3</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="flex items-center p-6">
            <Award className="h-8 w-8 text-green-500 mr-4" />
            <div>
              <p className="text-sm text-gray-500">Average Score</p>
              <p className="text-2xl font-bold">88%</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="flex items-center p-6">
            <BookOpen className="h-8 w-8 text-purple-500 mr-4" />
            <div>
              <p className="text-sm text-gray-500">Completed Tasks</p>
              <p className="text-2xl font-bold">12</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <Tabs defaultValue="assignments" className="space-y-4">
        <TabsList>
          <TabsTrigger value="assignments">Assignments</TabsTrigger>
          <TabsTrigger value="performance">Performance</TabsTrigger>
          <TabsTrigger value="recommendations">Recommendations</TabsTrigger>
        </TabsList>

        <TabsContent value="assignments">
          <Card>
            <CardHeader>
              <CardTitle>Current Assignments</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {assignments.map(assignment => (
                  <div key={assignment.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div>
                      <h3 className="font-medium">{assignment.title}</h3>
                      <p className="text-sm text-gray-500">{assignment.subject}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm">Due: {assignment.dueDate}</p>
                      <span className={`inline-block px-2 py-1 rounded text-xs ${
                        assignment.status === 'graded' ? 'bg-green-100 text-green-800' :
                        assignment.status === 'submitted' ? 'bg-blue-100 text-blue-800' :
                        'bg-yellow-100 text-yellow-800'
                      }`}>
                        {assignment.status.charAt(0).toUpperCase() + assignment.status.slice(1)}
                      </span>
                      {assignment.score && <p className="mt-1 font-medium">{assignment.score}%</p>}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="performance">
          <Card>
            <CardHeader>
              <CardTitle>Performance Trends</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={performanceData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip />
                    <Line type="monotone" dataKey="Mathematics" stroke="#2563eb" />
                    <Line type="monotone" dataKey="Physics" stroke="#16a34a" />
                    <Line type="monotone" dataKey="English" stroke="#9333ea" />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="recommendations">
          <Card>
            <CardHeader>
              <CardTitle>Recommended Resources</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {recommendations.map(resource => (
                  <Card key={resource.id}>
                    <CardContent className="p-4">
                      <div className="flex items-start space-x-4">
                        <Video className="h-8 w-8 text-blue-500" />
                        <div>
                          <h3 className="font-medium">{resource.title}</h3>
                          <p className="text-sm text-gray-500">{resource.subject}</p>
                          <div className="mt-2 flex items-center space-x-2">
                            <span className="px-2 py-1 bg-blue-100 text-blue-800 rounded-full text-xs">
                              {resource.difficulty}
                            </span>
                            <span className="text-sm text-gray-500">{resource.duration}</span>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
    
  );
};

export default StudentDashboard;    