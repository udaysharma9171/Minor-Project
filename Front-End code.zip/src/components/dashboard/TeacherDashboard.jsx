import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "../../components/ui/card";
import { useAuth } from '../../contexts/AuthContext';
import { BookOpen, Users, CheckCircle } from 'lucide-react';

const TeacherDashboard = () => {
  const { user, logout } = useAuth();

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      {/* Header Section */}
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Welcome, {user?.fullName || 'Teacher'}!</h1>
        <div className="flex items-center space-x-4">
          <div className="text-sm text-gray-500">
            {user?.department || 'Department Not Specified'}
          </div>
          <button 
            onClick={logout} 
            className="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600"
          >
            Logout
          </button>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="flex items-center p-6">
            <Users className="h-8 w-8 text-blue-500 mr-4" />
            <div>
              <p className="text-sm text-gray-500">Total Students</p>
              <p className="text-2xl font-bold">50</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="flex items-center p-6">
            <BookOpen className="h-8 w-8 text-green-500 mr-4" />
            <div>
              <p className="text-sm text-gray-500">Active Courses</p>
              <p className="text-2xl font-bold">5</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="flex items-center p-6">
            <CheckCircle className="h-8 w-8 text-purple-500 mr-4" />
            <div>
              <p className="text-sm text-gray-500">Assignments Graded</p>
              <p className="text-2xl font-bold">120</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content Area */}
      <div className="grid md:grid-cols-2 gap-6">
        {/* Upcoming Assignments */}
        <Card>
          <CardHeader>
            <CardTitle>Upcoming Assignments</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[
                { title: "Math Quiz", dueDate: "2024-12-15", subject: "Mathematics" },
                { title: "Science Project", dueDate: "2024-12-20", subject: "Science" },
                { title: "Literature Essay", dueDate: "2024-12-25", subject: "English" }
              ].map((assignment, index) => (
                <div key={index} className="border-b pb-2 last:border-b-0">
                  <div className="flex justify-between">
                    <div>
                      <p className="font-medium">{assignment.title}</p>
                      <p className="text-sm text-gray-500">{assignment.subject}</p>
                    </div>
                    <span className="text-sm text-gray-600">
                      Due: {assignment.dueDate}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Recent Activity */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Activity</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[
                { action: "Graded Math Quiz", student: "John Doe", time: "2 hours ago" },
                { action: "Assigned Science Project", student: "Class 10-A", time: "5 hours ago" },
                { action: "Updated Course Materials", student: "All Students", time: "1 day ago" }
              ].map((activity, index) => (
                <div key={index} className="border-b pb-2 last:border-b-0">
                  <p className="font-medium">{activity.action}</p>
                  <div className="flex justify-between text-sm text-gray-500">
                    <span>{activity.student}</span>
                    <span>{activity.time}</span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default TeacherDashboard;