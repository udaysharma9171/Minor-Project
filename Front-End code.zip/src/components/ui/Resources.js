import React, { Component } from 'react';
import axios from 'axios';

class Resources extends Component {
  state = {
    resources: [],
    loading: true,
    error: null,
  };

  // Fetch data from backend
  fetchResources = async () => {
    try {
      const response = await axios.get('/resources');
      this.setState({ resources: response.data.resources, loading: false });
    } catch (err) {
      console.error('Error fetching resources:', err);
      this.setState({ error: err.message, loading: false });
    }
  };

  // Fetch data after component mounts
  componentDidMount() {
    this.fetchResources();
  }
  render() {
    const { resources, loading, error } = this.state;

    if (loading) return <p>Loading...</p>;
    if (error) return <p>Error: {error}</p>;

    return (
      <div>
        <h1>Resources</h1>
        <ul>
          {resources.map((resource, index) => (
            <li key={index}>{resource.name}</li>
          ))}
        </ul>
      </div>
    );
  }
}

export default Resources;
